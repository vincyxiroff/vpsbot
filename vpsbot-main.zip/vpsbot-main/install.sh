wget https://github.com/dxomg/vpsbot/raw/main/dockerbot/install.py
python3 install.py
